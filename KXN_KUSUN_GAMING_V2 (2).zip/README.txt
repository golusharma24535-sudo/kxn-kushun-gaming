KXN KUSUN GAMING V2
---------------------
Features:
- Public Join Request form
- Admin demo login
- Approve / reject join requests
- Member management
- Team management
- Match management
- Search members
- Responsive gaming UI
- Browser localStorage persistence

DEMO ADMIN:
Username: admin
Password: kxn123

IMPORTANT:
This version is an offline front-end demo. The login is NOT secure and data is stored only in the browser.
For a real public website with accounts, shared online member data and secure admin authentication, connect the project to Firebase or Supabase and deploy it with a backend/database.
