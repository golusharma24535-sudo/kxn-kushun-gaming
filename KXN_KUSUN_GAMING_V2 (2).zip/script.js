const KEY="kxn_kusun_v2";
const seed={pending:[],members:[
{id:1,name:"KXN KUSUN",uid:"123456789",ign:"KXN KUSUN",role:"IGL",contact:"",team:"KXN Alpha",status:"Active"},
{id:2,name:"KXN RUSH",uid:"987654321",ign:"KXN RUSH",role:"Rusher",contact:"",team:"KXN Alpha",status:"Active"}],
teams:[{id:1,name:"KXN Alpha",captain:"KXN KUSUN",players:"4"}],
matches:[{id:1,title:"KXN Squad Battle",date:"2026-10-03",time:"20:00",opponent:"Team Phoenix"}]};
let db=JSON.parse(localStorage.getItem(KEY)||"null")||seed;
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const initials=s=>esc(s.split(/\s+/).map(x=>x[0]).slice(0,2).join("").toUpperCase());
function save(){localStorage.setItem(KEY,JSON.stringify(db));render()}
function render(){
 $("#mCount").textContent=db.members.length;$("#pCount").textContent=db.pending.length;$("#tCount").textContent=db.teams.length;$("#xCount").textContent=db.matches.length;
 const q=$("#search").value.toLowerCase();
 $("#membersGrid").innerHTML=db.members.filter(m=>(m.name+" "+m.ign+" "+m.uid+" "+m.team).toLowerCase().includes(q)).map(m=>`
 <article class="card"><div class="top"><div class="avatar">${initials(m.ign||m.name)}</div><div><b>${esc(m.ign||m.name)}</b><div class="muted">UID: ${esc(m.uid)}</div></div></div>
 <span class="tag">${esc(m.role)}</span><span class="tag">${esc(m.team)}</span><p class="muted">Status: ${esc(m.status)}</p></article>`).join("")||'<div class="card">No members found.</div>';
 $("#teamsGrid").innerHTML=db.teams.map(t=>`<article class="card"><div class="eyebrow">⚡ SQUAD</div><h3>${esc(t.name)}</h3><p class="muted">Captain: ${esc(t.captain)}</p><p class="muted">Players: ${esc(t.players)}</p></article>`).join("");
 $("#matchesGrid").innerHTML=db.matches.map(m=>`<article class="match"><div><b>${esc(m.title)}</b><div class="muted">${esc(m.date)} • ${esc(m.time)}</div></div><div class="vs">VS</div><div class="right"><b>${esc(m.opponent)}</b></div></article>`).join("");
 renderAdmin();
}
function renderAdmin(){
 $("#pendingList").innerHTML=db.pending.length?db.pending.map(m=>`<div class="request"><b>${esc(m.ign)}</b><div class="muted">${esc(m.name)} • UID ${esc(m.uid)} • ${esc(m.role)} • ${esc(m.contact)}</div><div class="actions"><button class="btn red mini" onclick="approve(${m.id})">Approve</button><button class="btn mini danger" onclick="reject(${m.id})">Reject</button></div></div>`).join(""):"<p class='muted'>No pending requests.</p>";
 $("#approvedList").innerHTML=db.members.map(m=>`<div class="adminrow"><div><b>${esc(m.ign)}</b><div class="muted">${esc(m.team)} • ${esc(m.role)}</div></div><button class="btn mini danger" onclick="removeMember(${m.id})">Remove</button></div>`).join("");
 $("#adminTeams").innerHTML=db.teams.map(t=>`<div class="adminrow"><div><b>${esc(t.name)}</b><div class="muted">Captain: ${esc(t.captain)}</div></div><button class="btn mini danger" onclick="removeTeam(${t.id})">Delete</button></div>`).join("");
 $("#adminMatches").innerHTML=db.matches.map(m=>`<div class="adminrow"><div><b>${esc(m.title)}</b><div class="muted">${esc(m.date)} • ${esc(m.opponent)}</div></div><button class="btn mini danger" onclick="removeMatch(${m.id})">Delete</button></div>`).join("");
}
function show(id){$(id).classList.add("show")}function hide(id){$(id).classList.remove("show")}
$("#search").oninput=render;
$("#year").textContent=new Date().getFullYear();
$("#joinForm").onsubmit=e=>{e.preventDefault();let f=new FormData(e.target);db.pending.push({id:Date.now(),name:f.get("name"),uid:f.get("uid"),ign:f.get("ign"),role:f.get("role"),contact:f.get("contact")});save();e.target.reset();alert("Join request sent! Admin will review it.")};
$("#loginOpen").onclick=()=>show("#loginModal");
$$("[data-close]").forEach(x=>x.onclick=()=>x.closest(".modal").classList.remove("show"));
$("#loginForm").onsubmit=e=>{e.preventDefault();if($("#adminUser").value==="admin"&&$("#adminPass").value==="kxn123"){hide("#loginModal");show("#adminModal");e.target.reset()}else alert("Wrong demo login.")};
$("#logout").onclick=()=>hide("#adminModal");
$$(".adminnav button").forEach(b=>b.onclick=()=>{$$(".adminnav button").forEach(x=>x.classList.remove("active"));$$(".panel").forEach(x=>x.classList.remove("active"));b.classList.add("active");$("#"+b.dataset.panel).classList.add("active")});
window.approve=id=>{let m=db.pending.find(x=>x.id===id);if(m){db.members.push({...m,team:"Unassigned",status:"Active"});db.pending=db.pending.filter(x=>x.id!==id);save()}};
window.reject=id=>{db.pending=db.pending.filter(x=>x.id!==id);save()};
window.removeMember=id=>{if(confirm("Remove member?")){db.members=db.members.filter(x=>x.id!==id);save()}};
window.removeTeam=id=>{if(confirm("Delete team?")){db.teams=db.teams.filter(x=>x.id!==id);save()}};
window.removeMatch=id=>{if(confirm("Delete match?")){db.matches=db.matches.filter(x=>x.id!==id);save()}};
$("#teamForm").onsubmit=e=>{e.preventDefault();let f=new FormData(e.target);db.teams.push({id:Date.now(),name:f.get("name"),captain:f.get("captain"),players:f.get("players")});save();e.target.reset()};
$("#matchForm").onsubmit=e=>{e.preventDefault();let f=new FormData(e.target);db.matches.push({id:Date.now(),title:f.get("title"),date:f.get("date"),time:f.get("time"),opponent:f.get("opponent")});save();e.target.reset()};
render();
